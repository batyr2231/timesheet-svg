import { Timesheet } from './components/Timesheet/Timesheet';
import './App.scss';

function App() {
  return <Timesheet />;
}

export default App;